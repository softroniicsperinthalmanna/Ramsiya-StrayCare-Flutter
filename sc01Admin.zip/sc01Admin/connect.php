<?php 
$con= new mysqli('localhost','root','','straycare_db');
// if($con->connect_error){
//     die("Connection Failed".$con->connect_error);
//  }

?>