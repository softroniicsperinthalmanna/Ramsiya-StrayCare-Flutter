<?php
$con = new mysqli('localhost','root','','straycare_db');

// if($con) {
//     echo 'Succesful';
// }
// else {
//     echo 'Failed';
// }

// $dbHost='localhost';
// $dbUsername='root';
// $dbPassword='';
// $dbName='straycare_db';
// $con=new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);
?>